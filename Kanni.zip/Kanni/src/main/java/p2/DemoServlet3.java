package p2;
import p2.Bill;
import java.io.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.*;
/**
 * Servlet implementation class ServeltDemo1
 */
@WebServlet("/ServeltDemo1")
public class DemoServlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DemoServlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try
		{
		int a=Integer.parseInt(request.getParameter("t1"));
		if(a<0) {
			out.println("Negative values not allowed");
		}
		else
		{
		int b=Integer.parseInt(request.getParameter("t2"));
		if(b<0) {
			out.println("Negative values not allowed");
		}
		else {
			
		int c=b-a;
		if(c<0) {
			out.println("Negative values not allowed");
		}
		else {
			double amt1=Bill.calculateBill(c);
			out.println("Bill is "+amt1);
		}
		}
		}
		}
		catch (Exception e)
		{
			response.sendRedirect("Bill1.html");
		}
	}

}