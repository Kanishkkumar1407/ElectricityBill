package p2;

import jakarta.servlet.ServletException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class ServletDemo4
 */
public class ServletDemo4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletDemo4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try
		{
			int id=Integer.parseInt(request.getParameter("t1"));
			String name=request.getParameter("t2");
			int sal=Integer.parseInt(request.getParameter("t3"));
			Class.forName("com.mysql.cj.jdbc.Driver");
			out.println("Driver class loaded");
			System.out.println("Driver class loaded");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk","root","tiger");
			out.println("Connection is established");
			System.out.println("Connection is established");
			Statement st=con.createStatement();
			out.println("Statement is prepared");
			System.out.println("Statement is prepared");
			int i=st.executeUpdate("insert into employee1 values("+id+",'"+name+"',"+sal+")");
			if(i>0)
				out.println("Record inserted");
			else
				out.println("Record not inserted");
				con.close();
		}
		catch (Exception e)
				{
				    e.printStackTrace();
				}
		}
	}

