package p2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/ServletDemo5")
public class ServletDemo5 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ServletDemo5() {
        super();
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            int id = Integer.parseInt(request.getParameter("t1"));
            String name = request.getParameter("t2");
            int m1 = Integer.parseInt(request.getParameter("t3"));
            int m2 = Integer.parseInt(request.getParameter("t4"));
            int m3 = Integer.parseInt(request.getParameter("t5"));
            int m4 = Integer.parseInt(request.getParameter("t6"));
            int m5 = Integer.parseInt(request.getParameter("t7"));
            int m6 = Integer.parseInt(request.getParameter("t8"));

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kanishk", "root", "tiger");
            Statement s = con.createStatement();

            // Insert operation
            int insertResult = s.executeUpdate("insert into student2 values(" + id + ",'" + name + "'," + m1 + "," + m2 + "," + m3 + "," + m4 + "," + m5 + "," + m6 + ")");
            if (insertResult > 0)
                out.println("Insert Successful");
            else
                out.println("Insert not successful");
        } catch (Exception e) {
            response.sendRedirect("Student.html");
        }

    }
}
