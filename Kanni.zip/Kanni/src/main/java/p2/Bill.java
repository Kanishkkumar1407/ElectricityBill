package p2;

import java.util.Scanner;

public class Bill {

    public static double calculateBill(int units) {
    	if (units < 0) {
            throw new IllegalArgumentException("Units cannot be negative. Please enter a valid number of units.");
        }
        double bill = 0.0;

        if (units <= 50) {
            bill = units * 1.50;
        } else if (units <= 100) {
            bill = 50 * 1.50 + (units - 50) * 2.00;
        } else if (units <= 150) {
            bill = 50 * 1.50 + 50 * 2.00 + (units - 100) * 3.50;
        } else {
            bill = 50 * 1.50 + 50 * 2.00 + 50 * 3.50 + (units - 150) * 5.00;
        }

        // Ensure the minimum bill amount is 100 rupees
        return Math.max(bill, 100.0);
    }
}