package p1;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.*;


public class ServletDemo2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ServletDemo2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("t1");
		String pwd=request.getParameter("t2");
		PrintWriter pw=response.getWriter();
		pw.println("Entered name is "+name);
		pw.println("Entered password is "+pwd);
		}

}
